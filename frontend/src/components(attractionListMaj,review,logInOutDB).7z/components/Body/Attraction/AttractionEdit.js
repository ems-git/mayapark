import React, { Component } from 'react'

/** App.js => AttractionIndex.js => AttractionList.js => Attraction.js  => AttractionEdit.js*/
class AttractionEdit extends Component {
    state = {
        id_atr : this.props.attraction.id_atr,
        titleValue : this.props.attraction.name,
        descValue : this.props.attraction.description,
    }

    inputOnChange=(e)=>
    {
        const {name, value} = e.target;
        this.setState({[name] : value});
    }
    
    onclick=()=>
    {
        this.props.editAtrIsClicked(this.state.titleValue,this.state.descValue);
    }

    render() {
        if (this.props.indexAtr % 2 === 0) return (
                <div className="atrContainer bgColorWhite">
                    <img className="atrImg"
                        src={this.props.attraction.img_url}
                        alt={this.props.attraction.name} />
                    <div className="descArt flexStart">
                        <div className="descArtTxtBox">
                            <article className="descArtTxt">
                                <button
                                    className="adminBtn editActive bgImgFit editR"
                                    onClick={this.onclick}>
                                </button>
                                <input
                                    name ="titleValue"
                                    value={this.state.titleValue}
                                    onChange={this.inputOnChange}/>
                                <input
                                    name ="descValue"
                                    value={this.state.descValue}
                                    onChange={this.inputOnChange}/>
                            </article>
                        </div>
                    </div>
                    
                </div>
            );

        else return (
            <div className="atrContainer bgColorGrey">
                <div className="descArt flexEnd">
                    <div className="descArtTxtBox">
                        <article className="descArtTxt">
                            <button
                                className="adminBtn editActive bgImgFit editL"
                                onClick={this.onclick}>
                            </button>
                            <input
                                    name ="titleValue"
                                    value={this.state.titleValue}
                                    onChange={this.inputOnChange}/>
                                <input
                                    name ="descValue"
                                    value={this.state.descValue}
                                    onChange={this.inputOnChange}/>
                        </article>
                    </div>
                </div>
                <img className="atrImg"
                    src={this.props.attraction.img_url}
                    alt={this.props.attraction.name}/>
            </div>
        );
    }
}
export default AttractionEdit;