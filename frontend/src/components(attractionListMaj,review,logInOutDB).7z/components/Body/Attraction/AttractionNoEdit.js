import React, { Component } from 'react';
import Review from './Review/Review'

/** App.js => AttractionIndex.js => AttractionList.js => Attraction.js  => AttractionNoEdit.js*/
class AttractionNoEdit extends Component {

    onclick=()=>
    {
        this.props.editAtrIsClicked();
    }
    
    render() {
        if (this.props.indexAtr % 2 === 0) return (
                <div className="atrContainer bgColorWhite">
                    <img className="atrImg"
                        src={this.props.attraction.img_url}
                        alt={this.props.attraction.name} />
                    <div className="descArt flexStart">
                        <div className="descArtTxtBox">
                            <article className="descArtTxt">
                                {
                                    /* Button edit */
                                    this.props.currentUser.type==="admin"?
                                    <button
                                        className="adminBtn editInactive bgImgFit editR"
                                        onClick={this.onclick}
                                        ></button>
                                    :
                                    ""
                                }
                                <h4>{this.props.attraction.name}</h4>
                                <p className="txtC">{this.props.attraction.description}</p>
                            </article>
                        </div>
                        <Review
                            rating={this.props.attraction.rating}
                            ratingNbr={this.props.attraction.ratingNbr}
                            currentUser={this.props.currentUser}
                            updateUserRating={this.props.updateUserRating}/>
                    </div>
                    
                </div>
            );

        else return (
            <div className="atrContainer bgColorGrey">
                <div className="descArt flexEnd">
                    <div className="descArtTxtBox">
                        <article className="descArtTxt">
                            {
                                /* Button edit */
                                this.props.currentUser.type === "admin" ?
                                    <button
                                        className="adminBtn editInactive bgImgFit editL"
                                        onClick={this.onclick}
                                    ></button>
                                    :
                                    ""
                            }
                            <h4>{this.props.attraction.name}</h4>
                            <p className="txtC">{this.props.attraction.description}</p>
                        </article>
                    </div>
                    <Review
                        rating={this.props.attraction.rating}
                        ratingNbr={this.props.attraction.ratingNbr}
                        currentUser={this.props.currentUser}
                        updateUserRating={this.props.updateUserRating}/>
                </div>
                <img className="atrImg"
                    src={this.props.attraction.img_url}
                    alt={this.props.attraction.name}/>
            </div>
        );
    }
}

export default AttractionNoEdit;