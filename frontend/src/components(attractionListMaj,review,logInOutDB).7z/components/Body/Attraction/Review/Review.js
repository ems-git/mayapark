import React, { Component } from 'react'
import Star from './Star'

/** App.js => AttractionIndex.js => AttractionList.js => Attraction.js =>Review*/
class Review extends Component {

    state ={
        nbrStar : 5,
    }

    starBoard=(pLimitStar)=>
    {
        let starBoard = [];
        for(let i = 0; i<this.state.nbrStar; i++)
        {
            let isActive;
            i<pLimitStar ? isActive=true : isActive=false;
            
            starBoard.push(<Star
                starIndex={i}
                currentUser={this.props.currentUser}
                isActive={isActive}
                updateUserRating={this.props.updateUserRating}
                key={`review${i}` }
                />)
        }
        return  starBoard;
    }

    updateStarLimit=()=>
    {
        let currentRating=Math.round((this.props.rating)*5);
        if(currentRating>=5) return this.starBoard(5);
        else if(currentRating>=4) return this.starBoard(4);
        else if (currentRating>=3) return this.starBoard(3);
        else if (currentRating>=2) return this.starBoard(2);
        else if (currentRating>=1) return this.starBoard(1);
        else return this.starBoard(0);

    }
    render() {
        return (
            <div className="ratingContainer">
                {this.updateStarLimit()}
                <div className="reviewTxt">
                    <h5>{Math.round((this.props.rating)*5)}/5</h5>
                    <p>{`${this.props.ratingNbr} votes`}</p>
                </div>
            </div>
        )
    }
}
export default Review;