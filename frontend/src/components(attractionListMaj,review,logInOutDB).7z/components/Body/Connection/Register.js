import React, { Component } from 'react'

/** App.js => ConnectionIndex.js => Register.js */
export default class Register extends Component {

    state =
    {
        id: null,
        type: "user",
        isLog:true,
        mail: "",
        password: "",
        pseudo :"",
        birthday:"",
        firstName : "",
        name : "",
        
        confPassword: "",
    }

    inputText = (e) => 
    {
        const {name, value} = e.target; 
        this.setState({[name]: value}); 
    }
    
    createUser = (e) => 
    {
        e.preventDefault();
    }

    renderForm =()=>
    {
        let informations = ["name", "firstName","pseudo","birthday","mail","password","confPassword"];
        let labels = ["Prenom", "Nom","Pseudo","Date de naissance","Adress e-mail","Mot de pass","Confirmation mot de passe"];
        let placeholders = ["prénom", "nom de famille","pseudo","dadte de naissance","e-mail","mot de passe","de nouveau votre mot de pass"];
        let formContent =[];
        for(let i=0;  i<informations.length; i++)
        {
            formContent.push(
                <div key={i} className="FlexCol itemC">
                    <label htmlFor="mail">{labels[i]}</label>
                    <input
                        name={informations[i]}
                        onChange={this.inputText}
                        value={this.state[informations[i]]}
                        type="text"
                        placeholder={`Saisisser votre adresse mail ${placeholders[i]}`}/>
                </div>
            )
        }
        return formContent;
    }

    render()
    {

        return (
            <section className="connectionSection">
                <h1>INSCRIPTION</h1>
                <form className="FlexCol itemC">
                    {this.renderForm()}
                    <button
                        className="submitBtn"
                        type="submit"
                        onClick={this.createUser}>CREER COMTPE</button>
                </form>
            </section>
            
        )
    }
}
