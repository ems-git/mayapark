//REACT import
import React, { Component } from 'react';
// JS import
// import GlobalVar from "../GlobalVar";

/** App.js => Navbar.js => SearchWind.js*/
class SearchWind extends Component {
    state =
        {
            search: "",
        };

    inputChange=(e)=>//  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   UPDATE INPUT VALUE
    {
        this.setState({search : e.target.value}, ()=>{
           this.props.clearMarkSearch(this.state.search);
        });
    }
    
    render()//  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   RENDER
    {
        return (
                <div id="searchWind">
                    <input id="searchInput"
                        type="search"
                        className="searchInput"
                        placeholder="Recherche..."
                        value={this.state.search}
                        onChange={this.inputChange} />
                    <div className="serachBtnBox">
                        <button id="searchPrev"
                            className="searchBtn "
                            onClick={()=>this.props.navMark(true)}
                            >prev</button>
                        <button id="searchNxt"
                            className="searchBtn"
                            onClick={()=>this.props.navMark(false)}
                            >next</button>
                    </div>
                </div>
        );
    }

}
  
  export default SearchWind;