//REACT import
import { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Redirect } from "react-router-dom";
//CSS import
import '../../css/cssVar.css';
import '../../css/font.css';
import '../../css/anim.css';
import '../../css/app.css';
import '../../css/navbar.css';
// JS import
import GlobalVar from "../GlobalVar"

import AttractionIndex from '../Body/Attraction/AttractionIndex';
import HomeIndex from '../Body/Home/HomeIndex';
import ConnectionIndex from '../Body/Connection/ConnectionIndex';
import ProfilIndex from '../Body/Profil/ProfilIndex';
import AccountIndex from '../Body/Account/AccountIndex';
import NotFoundIndex from '../Body/NotFound/NotFoundIndex';


class App extends Component {

    state =
        {
            users: [],
            currentUser: {
                id:null,
                type: null,
            },
            markId: 0,
        }

    /*componentDidMount()
    {
        console.log('App.js - componentDidMount() "recuperation user"');

        GlobalVar.axios.get(`${GlobalVar.url}userList`)
            .then(response => {

                let userData = response.data.map(element => {
                    if (element.birthday != null) {
                        let elemDate = element.birthday.slice(0, 10);
                        element.birthday = elemDate;
                    }
                    return element;
                });
                this.updateUsersFromData(userData);
            })
            .catch(error => {
                console.log('App.js - componentDidMount() GET-user ERROR : ', error);
            });
    }
    updateUsersFromData = (pDataResponse) => {
        console.log('App.js - updateUsersFromData()');

        this.setState({ users: pDataResponse });
    }*/

    /*-----------------------------------------------------------------------------------------------*/
    /*   .   .   .   .   .   .   .   .   .   .   .DATABASE.   .   .   .   .   .   .   .   .   .   .  */
    /*-----------------------------------------------------------------------------------------------*/

    /** App.js CHECK IN DATABASE IF USER EXIST
     * @param {String} pMail mail of user */
    doesUserExistDB=(pMail)=>
    {
        console.log('App.js - doesUserExist()');
    }

    /** App.js CREATE NEW USER IN DATA BASE
     * @param {Object} pUser  */
    createUserDB=(pUser)=>
    {
        console.log('App.js - addUserDB()');
    }

    /** App.js CHECK IN DATA BASE IF MAIL AND PASSWORD IS OK
     *  @param {String} pMail email of user
     * @param {String} pPassword password of user */
    checkConnectionDB=(pMail,pPassword)=>
    {
        console.log('App.js - checkConnectionDB()');
        GlobalVar.axios.get(`${GlobalVar.url}user/mail/${pMail}/password/${pPassword}`)
            .then(response => {
                
                let userType = response.data[0].type;
                let userId = response.data[0].id_user;
                this.setCurrUser(userType,userId);
            })
            .catch(error =>
            {
                if(error.response && error.response.data && error.response.data.errorsValidator)
                {
                    console.log('App.js - checkConnectionDB GET-user ERROR validator : ',  error.response.data.errorsValidator);
                    this.showErrorMsg(error.response.data.errorsValidator);
                }
                else
                {
                    console.log('App.js - checkConnectionDB GET-user ERROR Callback: ', error);
                    this.showErrorMsg("Mot de passe ou identifiant incorrect. \nSi vous n'êtes pas encore inscrit, enregistrez vouss :)");
                } 
            });
    }

    /** App.js CHANGE VALUE OF LOG IN DATA BASE WHEN USER IS LOG OR NOT
     * @param {Number} pId id of current user
     * @param {Boolean} pLogin true if user is log, false if he si not login */
    logUser=(pId, pLogin)=>
    {
        console.log('App.js - logUser()');

        let isLog;
        //In data base, boolean is 0 or 1
        if(pLogin===true) isLog=1;
        else if(pLogin===false) isLog=0;

        GlobalVar.axios.put(`${GlobalVar.url}user/id/${pId}/isLog/${isLog}`)
            .then(response => {
                
                console.log('App.js - logUser(): ', response);
            })
            .catch(error =>
            {
                console.log('App.js - logUser() Callback: ', error);
            });
    }


    /*-----------------------------------------------------------------------------------------------*/
    /*   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   */
    /*-----------------------------------------------------------------------------------------------*/

    /** App.js SET CURRENT USER TYPE AFTER CONNECTION/DECONNECTION
     * @param {String} pType user type : admin, user or null*/
     setCurrUser=(pType,pId)=>
     {
        if(pId)
        {
            this.setState({currentUser : {id : pId , type : pType}}, this.logUser(pId,true));
        }
        else
        {
            this.logUser(this.state.currentUser.id,false);
            this.setState({currentUser : {id : pId , type : pType}});
        }
        
     }

    /*-----------------------------------------------------------------------------------------------*/
    /*   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   */
    /*-----------------------------------------------------------------------------------------------*/

    showErrorMsg=(pErrors)=>
    {
        if(Array.isArray(pErrors))
        {
            let msgError = "";
            pErrors.forEach(element => {
                msgError += `- ${element}\n`;
            });
            
            alert(msgError);
        }
        else
        {
            alert(pErrors);
        }
    }

    /*-----------------------------------------------------------------------------------------------*/
    /*   .   .   .   .   .   .   .   .   .SEARCH ON PAGE METHODE.   .   .   .   .   .   .   .   .   .*/
    /*-----------------------------------------------------------------------------------------------*/
    /*
    /** App.js - ADD <mark> ON INNER HTML
     * @param {String} pFocusWord the word to focus (on input search) *
    addMarkSearch = (pFocusWord) => {
        console.log("addMarkSearch word:", pFocusWord);

        let currentBody = document.querySelector("#currentBody");
        let currentText = currentBody.innerHTML;
        let newTxt = currentText.replaceAll(pFocusWord, ("<mark>" + pFocusWord + "</mark>"));

        currentBody.innerHTML = newTxt;
    }

    /** App.js - CLEAR ALL <mark> ON INNER HTML 
    * @param {String} pFocusWord the word to focus (on input search) *
    clearMarkSearch = (pFocusWord) => {
        console.log("clearMarkSearch word:", pFocusWord);

        this.clearMarkId();

        let currentBody = document.querySelector("#currentBody");

        if (currentBody.querySelectorAll("mark").length > 0) {
            // let currentRegex = /(<mark>|<mark/>)/g;
            let currentInner = document.querySelector("#currentBody").innerHTML;
            let newInner = currentInner.replaceAll("<mark>", "");
            newInner = newInner.replaceAll("<mark/>", "");
            document.querySelector("#currentBody").innerHTML = newInner;
        }

        if (currentBody.textContent.search(pFocusWord) > 0) this.addMarkSearch(pFocusWord);

    }

    /** App.js - NAVIGATION ON <MARK> WITH SCROLL TO
     * @param {Boolean} pPrev true if searchPrev(SearchWind.js) is clicked, false if searchNxt(SearchWind.js) is clicked  *
    navMark = (pPrev) => {
        if (document.getElementsByTagName("mark").length !== 0) {
            let marks = Array.from(document.getElementsByTagName("mark"));

            if (pPrev) this.setMarkId(-1, marks);
            else this.setMarkId(+1, marks);

        }
    }

    /** App.js - SET ID OF CUTENT <MARKS>
     * @param {Number} pValue -1 if searchPrev(SearchWind.js) is clicked, +1 if searchNxt(SearchWind.js) is clicked
     * @param {Array} pMarks  Array of all <marks> *
    setMarkId = (pValue, pMarks) => {

        let newMarkId = this.state.markId + pValue;
        if (newMarkId < 0) {
            newMarkId = pMarks.length - 1;
            this.setState({ markId: newMarkId }, () => this.scrollToMark(pMarks));
        }
        else if (newMarkId >= pMarks.length) {
            newMarkId = 0;
            this.setState({ markId: newMarkId }, () => this.scrollToMark(pMarks));
        }
        else this.setState({ markId: newMarkId }, () => this.scrollToMark(pMarks));
    }

    /** App.js - CLEAR MARKID*
    clearMarkId = () => {
        this.setState({ markId: 0 });
    }

    /** App.js - SCROLL TO CURRENT <MARK>
     * @param {Array} pMarks Array of all <marks> *
    scrollToMark = (pMarks) => {
        let moveToY = pMarks[this.state.markId].offsetTop - document.querySelector(".navbarContainer").offsetHeight
        window.scrollTo(0, moveToY);
    }
    */

    /*-----------------------------------------------------------------------------------------------*/
    /*   .   .   .   .   .   .   .   .   .   .   .RENDER.   .   .   .   .   .   .   .   .   .   .   .*/
    /*-----------------------------------------------------------------------------------------------*/
    render() {
        
        return (
            <div className="App">
                <Router>

                    <Switch>

                        <Route exact path="/attraction">
                            <AttractionIndex
                                clearMarkSearch={this.clearMarkSearch}
                                navMark={this.navMark}
                                clearMarkId={this.clearMarkId}
                                currentUser={this.state.currentUser}
                                setCurrUser={this.setCurrUser}
                            />;
                        </Route>

                        <Route exact path="/connection">
                        {this.state.currentUser.type === null ? 
                            <ConnectionIndex
                                clearMarkSearch={this.clearMarkSearch}
                                navMark={this.navMark}
                                clearMarkId={this.clearMarkId}
                                currentUser={this.state.currentUser}
                                setCurrUser={this.setCurrUser}

                                doesUserExistDB={this.doesUserExistDB}
                                createUserDB={this.createUserDB}
                                checkConnectionDB={this.checkConnectionDB}
                            />
                        :
                        <Redirect  to="/"/>
                        }
                        </Route>

                        <Route exact path="/profil">
                        {this.state.currentUser.type ==="user" ? 
                            <ProfilIndex
                                clearMarkSearch={this.clearMarkSearch}
                                navMark={this.navMark}
                                clearMarkId={this.clearMarkId}
                                currentUser={this.state.currentUser}
                                setCurrUser={this.setCurrUser}
                            />
                            :
                        <Redirect  to="/"/>
                        }
                            
                        </Route>

                        
                        <Route exact path="/compteManagement">
                        {this.state.currentUser.type ==="admin" ? 
                            <AccountIndex
                                clearMarkSearch={this.clearMarkSearch}
                                navMark={this.navMark}
                                clearMarkId={this.clearMarkId}
                                currentUser={this.state.currentUser}
                                setCurrUser={this.setCurrUser}
                            />
                            :
                            <Redirect  to="/"/>
                        }
                        </Route>

                        <Route exact path="/">
                            <HomeIndex
                                clearMarkSearch={this.clearMarkSearch}
                                navMark={this.navMark}
                                clearMarkId={this.clearMarkId}
                                currentUser={this.state.currentUser}
                                setCurrUser={this.setCurrUser}
                            />
                        </Route>

                            <NotFoundIndex
                                clearMarkSearch={this.clearMarkSearch}
                                navMark={this.navMark}
                                clearMarkId={this.clearMarkId}
                                currentUser={this.state.currentUser}
                                setCurrUser={this.setCurrUser}
                            />
                    </Switch>
                </Router>
            </div>
        );
    }
}

export default App;